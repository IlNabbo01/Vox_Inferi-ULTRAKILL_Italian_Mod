Full credit goes to the UltrakULL team for the original mod.

I’m only responsible for the Italian translation.

If you enjoy this project, please consider supporting them:

[DISCORD](https://discord.gg/YYJB9VCY)

[MOD PAGE](https://thunderstore.io/c/ultrakill/p/UltrakULL/UltrakULL/)



##### **ULTRAKILL - Vox Inferi 1.0**



**ENGLISH:**



Hey! If you're reading this, it means you downloaded this mod, and I'm really grateful for that, so here are the steps.



**step 1:** Open the BepInEx folder (that should be like "\*YOUR DISK\*:\\\*YOUR FOLDER\*\\steam\\steamapps\\common\\ULTRAKILL\\BepInEx)



**step 2:** Place the 2 folders of the mod (config and plugins) into the BepInEx folder, If it asks you to overwrite the files because they already exist, select yes.



**step 3:** When you open the game, you'll see a new checkbox in the settings, "Languages," and from there you can select Italian.





If you want to use Italian dubbing, you'll need to go to the audio settings and enable the "dubbing" checkbox. But please note:



⚠ Note: this is version 1.0 of the mod, meaning it's only for text; **dubbing is still being done!**









**ITALIAN:**



Ciao!

Se stai leggendo questo file significa che hai scaricato la mod, e te ne sono davvero grato. Ecco i passaggi per installarla:



**Passaggio 1:**

Apri la cartella BepInEx (dovrebbe trovarsi in: \*TUO DISCO\*:\\\*TUA CARTELLA\*\\steam\\steamapps\\common\\ULTRAKILL\\BepInEx)



**Passaggio 2:**

Copia le 2 cartelle della mod (config e plugins) dentro la cartella BepInEx.

Se ti viene chiesto di sovrascrivere i file perché già esistono, seleziona Sì.



**Passaggio 3:**

Avvia il gioco.

Nelle impostazioni troverai una nuova sezione chiamata "Languages": da lì potrai selezionare l’italiano.





Se desideri attivare il doppiaggio in italiano, vai nelle impostazioni audio e attiva la casella "Dubbing".



⚠ Nota: questa è la versione 1.0 della mod, quindi al momento include solo la traduzione dei testi. **Il doppiaggio è ancora in fase di realizzazione!**

